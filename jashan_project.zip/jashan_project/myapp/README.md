chirpIt

Project Overview

chirpIt is a backend application crafted with Node.js and Express, providing comprehensive functionality for user management, post creation, and interactions. It’s designed to handle everything from authentication to CRUD operations efficiently.

Key Features

User Authentication: Secure sign-up and login with JWT.
Post Management: Full support for creating, reading, updating, and deleting posts.
User Interaction: Follow/unfollow users and like/unlike posts.
Comment Handling: Add, like, and reply to comments on posts.
Robust Error Handling: Comprehensive error management for a smooth user experience.
Input Validation: Ensures all inputs meet the required criteria.
Secure Password Storage: Passwords are safely hashed using bcrypt.
Technology Stack

Node.js: Server-side JavaScript runtime.
Express: Web framework for building RESTful APIs.
MongoDB: NoSQL database, managed with Mongoose.
JSON Web Tokens (JWT): For secure authentication mechanisms.
bcrypt: For hashing user passwords.
Joi: For data validation.


Installation Guide

Clone the Repository:

git clone https://github.com/your-username/your-repo.git
cd your-repo

install Dependencies:

npm install
npm install --save-dev nodemon
npm install express jsonwebtoken bcrypt multer

Update Package Scripts:
Edit the scripts section in your package.json to include:

"scripts": {
  "start": "nodemon server.js",
  "start-auth": "nodemon authServer.js"
}

Run the Servers:
Open two terminal windows and execute:

npm run start
npm run start-auth
