const { Comment, Response } = require("../models/feedback");
const { ChirpPost } = require("../models/post");
const { ChirpUser } = require("../models/user");

// Show comments for a specific post
const showComments = async (req, res, next) => {
    try {
        const postId = req.params.id;
        const currentUser = req.user;
        const post = await ChirpPost.findById(postId).populate("author");

        if (!post) {
            return res.status(404).json({
                error: "Post not found",
            });
        }

        const postAuthorId = post.author._id;
        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 10;
        const skip = (page - 1) * limit;

        const isFollowing = currentUser.following.includes(postAuthorId.toString());
        const isAuthor = currentUser._id.equals(postAuthorId);

        if (isFollowing || isAuthor) {
            const comments = await Comment.find({ associatedPost: postId })
                .sort({ createdAt: -1 })
                .skip(skip)
                .limit(limit)
                .populate("responses")
                .exec();

            const totalComments = await Comment.countDocuments({ associatedPost: postId });
            return res.json({
                comments,
                currentPage: page,
                totalPages: Math.ceil(totalComments / limit),
                totalComments,
            });
        } else {
            return res.status(403).json({
                error: "Access denied",
            });
        }
    } catch (error) {
        return res.status(500).json({ error: "Server error" });
    }
};

// Reply to a specific comment
const replyToComment = async (req, res, next) => {
    try {
        const currentUser = req.user;
        const commentId = req.params.id;
        const comment = await Comment.findById(commentId);
        const authorId = comment.author;
        const replyData = req.body;

        if (!comment) {
            return res.status(404).json({
                error: "Comment not found",
            });
        }

        if (currentUser.following.includes(authorId)) {
            const reply = await Response.create(replyData);
            comment.responses.push(reply._id);
            await comment.save();
            res.status(201).json({ message: "Reply added successfully!" });
        } else {
            return res.status(403).json({
                error: "Access denied",
            });
        }
    } catch (error) {
        console.error("Error replying to the comment:", error);
        return res.status(500).json({ error: "Server error" });
    }
};

// Like a specific comment
const likeComment = async (req, res, next) => {
    try {
        const currentUser = req.user;
        const commentId = req.params.id;
        const comment = await Comment.findById(commentId, 'author likedBy likeCount');
        const authorId = comment.author;

        if (!comment) {
            return res.status(404).json({
                error: "Comment not found",
            });
        }

        if (currentUser.following.includes(authorId)) {
            if (comment.likedBy.includes(currentUser._id)) {
                return res.status(403).json({
                    error: "Already liked",
                });
            }
            comment.likeCount += 1;
            comment.likedBy.push(currentUser._id);
            await comment.save();
            res.status(201).json({ message: "Comment liked successfully!" });
        } else {
            return res.status(403).json({
                error: "Access denied",
            });
        }
    } catch (error) {
        console.error("Error liking the comment:", error);
        return res.status(500).json({ error: "Server error" });
    }
};

// Unlike a specific comment
const unLikeComment = async (req, res, next) => {
    try {
        const currentUser = req.user;
        const commentId = req.params.id;
        const comment = await Comment.findById(commentId, 'author likedBy likeCount');
        const authorId = comment.author;

        if (!comment) {
            return res.status(404).json({
                error: "Comment not found",
            });
        }

        if (currentUser.following.includes(authorId)) {
            if (!comment.likedBy.includes(currentUser._id)) {
                return res.status(404).json({
                    error: "Not liked yet",
                });
            }
            comment.likeCount -= 1;
            comment.likedBy.pull(currentUser._id);
            await comment.save();
            res.status(200).json({ message: "Comment unliked successfully!" });
        } else {
            return res.status(403).json({
                error: "Access denied",
            });
        }
    } catch (error) {
        console.error("Error unliking the comment:", error);
        return res.status(500).json({ error: "Server error" });
    }
};

// Unlike a specific reply
const unLikeReply = async (req, res, next) => {
    try {
        const currentUser = req.user;
        const replyId = req.params.id;
        const reply = await Response.findById(replyId, 'author likedBy likeCount');
        const authorId = reply.author;

        if (!reply) {
            return res.status(404).json({
                error: "Reply not found",
            });
        }

        if (currentUser.following.includes(authorId)) {
            if (!reply.likedBy.includes(currentUser._id)) {
                return res.status(404).json({
                    error: "Not liked yet",
                });
            }
            reply.likeCount -= 1;
            reply.likedBy.pull(currentUser._id);
            await reply.save();
            res.status(200).json({ message: "Reply unliked successfully!" });
        } else {
            return res.status(403).json({
                error: "Access denied",
            });
        }
    } catch (error) {
        console.error("Error unliking the reply:", error);
        return res.status(500).json({ error: "Server error" });
    }
};

// Like a specific reply
const likeReply = async (req, res, next) => {
    try {
        const currentUser = req.user;
        const replyId = req.params.id;
        const reply = await Response.findById(replyId, 'author likedBy likeCount');
        const authorId = reply.author;

        if (!reply) {
            return res.status(404).json({
                error: "Reply not found",
            });
        }

        if (currentUser.following.includes(authorId)) {
            if (reply.likedBy.includes(currentUser._id)) {
                return res.status(403).json({
                    error: "Already liked",
                });
            }
            reply.likeCount += 1;
            reply.likedBy.push(currentUser._id);
            await reply.save();
            res.status(201).json({ message: "Reply liked successfully!" });
        } else {
            return res.status(403).json({
                error: "Access denied",
            });
        }
    } catch (error) {
        console.error("Error liking the reply:", error);
        return res.status(500).json({ error: "Server error" });
    }
};

module.exports = {
    feedbackRepository: {
        showComments,
        replyToComment,
        likeComment,
        unLikeComment,
        unLikeReply,
        likeReply
    },
};
