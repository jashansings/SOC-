const { ChirpPost } = require("../models/post");
const { ChirpUser } = require("../models/user");
const { feedback } = require("../models/feedback");

// Create a new post
const createPost = async (req, res, next) => {
  try {
    const { content } = req.body;
    const author = req.user._id;
    const image = req.file ? req.file.buffer : null;
    const imageType = req.file ? req.file.mimetype : null;

    const post = new ChirpPost({
      content,
      image,
      imageType,
      author,
    });

    await post.save();

    const user = await ChirpUser.findById(author);
    if (user) {
      user.posts.push(post._id);
      await user.save();
    }

    res.status(201).json({
      data: post,
      success: true,
      message: "Post created successfully",
      error: "",
    });
  } catch (error) {
    console.error('Error creating post:', error);
    res.status(500).json({
      data: null,
      success: false,
      message: "Error creating post",
      error: { error },
    });
  }
};

// Get all posts of a specific user
const getAllUserPosts = async (req, res) => {
  try {
    const userId = req.params.id;
    const currentUser = req.user;
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;

    const user = await ChirpUser.findById(userId);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    const isFollowing = currentUser.following.includes(userId);

    if (isFollowing || currentUser._id.equals(userId)) {
      const posts = await ChirpPost.find({ author: userId })
        .skip((page - 1) * limit)
        .limit(limit)
        .exec();

      const totalPosts = await ChirpPost.countDocuments({ author: userId });
      return res.json({
        posts,
        totalPosts,
        totalPages: Math.ceil(totalPosts / limit),
        currentPage: page
      });
    } else {
      return res.status(403).json({ error: 'Access denied. You are not a follower.' });
    }
  } catch (error) {
    return res.status(500).json({
      data: null,
      success: false,
      message: "Internal server error",
      error: { error },
    });
  }
};

// Edit a specific post
const editPost = async (req, res, next) => {
  try {
    const postId = req.params.id;
    const userId = req.user._id;
    const post = await ChirpPost.findById(postId);

    if (!post) {
      return res.status(404).json({ error: "Post not found" });
    }

    if (post.author.equals(userId)) {
      if (req.body.content) post.content = req.body.content;
      if (req.file) {
        post.image = req.file.buffer;
        post.imageType = req.file.mimetype;
      }
      await post.save();
      return res.json({ post });
    } else {
      return res.status(403).json({ error: "Access denied" });
    }
  } catch (error) {
    console.error("Error editing the post:", error);
    return res.status(500).json({ error: "Server error" });
  }
};

// Delete a specific post
const deletePost = async (req, res, next) => {
  try {
    const postId = req.params.id;
    const user = req.user;

    const post = await ChirpPost.findById(postId);
    if (!post) {
      return res.status(404).json({ error: "Post not found" });
    }

    if (!post.author.equals(user._id)) {
      return res.status(403).json({ error: "Access denied" });
    }

    user.posts = user.posts.filter(id => id.toString() !== postId);
    await user.save();
    await ChirpPost.findByIdAndDelete(postId);

    res.json({ success: true, message: 'Post deleted successfully' });
  } catch (error) {
    console.error("Error deleting the post:", error);
    return res.status(500).json({ error: "Server error" });
  }
};

// Comment on a specific post
const commentPost = async (req, res, next) => {
  try {
    const user = req.user;
    const postId = req.params.id;
    const post = await ChirpPost.findById(postId);
    const commentData = req.body;

    if (!post) {
      return res.status(404).json({ error: "Post does not exist" });
    }

    const authorId = post.author;

    if (user.following.includes(authorId)) {
      const comment = await Comment.create(commentData);
      post.comments.push(comment._id);
      await post.save();
      return res.status(200).json({ message: "Comment added successfully", comment });
    } else {
      return res.status(403).json({ error: "Cannot comment since you are not a follower of the author" });
    }
  } catch (error) {
    console.error("Error commenting on the post:", error);
    return res.status(500).json({ error: "Server error" });
  }
};

// Like a specific post
const likePost = async (req, res, next) => {
  try {
    const user = req.user;
    const postId = req.params.id;
    const post = await ChirpPost.findById(postId);

    if (!post) {
      return res.status(404).json({ error: "Post not found" });
    }

    if (user.following.includes(post.author)) {
      if (post.likes.includes(user._id)) {
        return res.status(403).json({ error: "Already liked" });
      }

      post.totalLikes += 1;
      post.likes.push(user._id);
      await post.save();

      return res.status(200).json({ message: "Liked successfully" });
    } else {
      return res.status(403).json({ error: "Cannot like since you are not a follower of the author" });
    }
  } catch (error) {
    console.error("Error liking the post:", error);
    return res.status(500).json({ error: "Server error" });
  }
};

// Unlike a specific post
const unlikePost = async (req, res, next) => {
  try {
    const user = req.user;
    const postId = req.params.id;
    const post = await ChirpPost.findById(postId);

    if (!post) {
      return res.status(404).json({ error: "Post not found" });
    }

    if (!post.likes.includes(user._id)) {
      return res.status(400).json({ error: "You have not liked this post" });
    }

    post.totalLikes -= 1;
    post.likes = post.likes.filter(userId => userId.toString() !== user._id.toString());
    await post.save();

    return res.status(200).json({ message: "Unliked successfully" });
  } catch (error) {
    console.error("Error unliking the post:", error);
    return res.status(500).json({ error: "Server error" });
  }
};

module.exports = {
  postRepository: {
    createPost,
    getAllUserPosts,
    editPost,
    deletePost,
    commentPost,
    unlikePost,
    likePost
  }
};
