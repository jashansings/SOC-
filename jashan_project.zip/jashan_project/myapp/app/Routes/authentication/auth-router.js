const express = require("express");
const jwt = require("jsonwebtoken");
const authRouter = express.Router();
const { refreshToken } = require("../../models/token");
const { User } = require("../../models/user");

// Signup route
authRouter.post("/signup", async (req, res, next) => {
  try {
    const { username, password, name, bio, gender } = req.body;

    // Check if the username already exists
    const existingUser = await User.findOne({ username });
    if (existingUser) {
      return res.status(400).json({ message: "Username already exists" });
    }

    // Create a new user
    const newUser = new User({ username, password, name, bio, gender });
    await newUser.save();

    // Generate tokens
    const accessToken = generateAccessToken({ username: newUser.username });
    const refreshToken = jwt.sign(
      { username: newUser.username },
      process.env.REFRESH_TOKEN_SECRET
    );

    // Save refresh token
    await refreshToken.create({ token: refreshToken, author: newUser.username });

    // Respond with tokens
    res.status(201).json({ accessToken, refreshToken });
  } catch (err) {
    console.error("Error during signup:", err);
    res.status(500).json({ message: "Server error" });
  }
});

// Login route
authRouter.post("/login", async (req, res, next) => {
  try {
    const { username, password } = req.body;

    // Check if the user exists
    const user = await User.findOne({ username });
    if (!user) {
      return res.status(400).json({ message: "Invalid username or password" });
    }

    // Check password match
    const isMatch = await user.comparePassword(password);
    if (!isMatch) {
      return res.status(400).json({ message: "Invalid username or password" });
    }

    // Generate tokens
    const accessToken = generateAccessToken({ username: user.username });
    const refreshToken = jwt.sign(
      { username: user.username },
      process.env.REFRESH_TOKEN_SECRET
    );

    // Save refresh token
    await refreshToken.create({ token: refreshToken, author: user.username });

    // Respond with access token
    res.json({ accessToken });
  } catch (err) {
    console.error("Error during login:", err);
    res.status(500).json({ message: "Server error" });
  }
});

// Token refresh route
authRouter.post("/token", async (req, res, next) => {
  const { token: refToken } = req.body;
  if (!refToken) return res.sendStatus(401);

  try {
    // Check if the refresh token is valid
    const tokenRecord = await refreshToken.findOne({ token: refToken });
    if (!tokenRecord) return res.sendStatus(403);

    // Verify the refresh token
    jwt.verify(refToken, process.env.REFRESH_TOKEN_SECRET, (err, user) => {
      if (err) return res.sendStatus(403);

      // Generate a new access token
      const accessToken = generateAccessToken({ username: user.username });
      res.json({ accessToken });
    });
  } catch (e) {
    console.error("Error refreshing token:", e);
    res.sendStatus(403);
  }
});

// Logout route
authRouter.delete("/logout", async (req, res, next) => {
  try {
    const { token } = req.body;
    await refreshToken.deleteOne({ token });
    res.status(200).json({ message: "Logout successful" });
  } catch (err) {
    console.error("Error during logout:", err);
    res.sendStatus(403);
  }
});

// Middleware to authenticate tokens
function authenticateToken(req, res, next) {
  const authHeader = req.headers["authorization"];
  const token = authHeader && authHeader.split(" ")[1];
  if (!token) return res.sendStatus(401).json({ message: "Token not provided" });

  jwt.verify(token, process.env.ACCESS_TOKEN_SECRET, async (err, user) => {
    if (err) return res.sendStatus(403).json({ message: "Invalid token" });

    const userRecord = await User.findOne({ username: user.username });
    req.user = userRecord;
    next();
  });
}

function generateAccessToken(user) {
  return jwt.sign(user, process.env.ACCESS_TOKEN_SECRET, { expiresIn: '15m' });
}

module.exports = { authRouter, authenticateToken };
