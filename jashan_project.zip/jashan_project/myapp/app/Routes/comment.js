const express = require("express");
const commentRouter = express.Router();
const { commentRepository } = require("../Repository/comments-repository");
const { authenticateToken } = require("../Routes/authentication/auth-router");
const { postRepository } = require("../Repository/posts-repository");

// Route to add a comment to a post
commentRouter.post("/:id", authenticateToken, commentRepository.commentPost);

// Route to view comments of a post
commentRouter.get("/:id", authenticateToken, commentRepository.showComments);

// Route to reply to a comment
commentRouter.post("/reply/:id", authenticateToken, commentRepository.replyToComment);

// Route to like a comment
commentRouter.patch("/like/:id", authenticateToken, commentRepository.likeComment);

// Route to unlike a comment
commentRouter.patch("/unlike/:id", authenticateToken, commentRepository.unlikeComment);

// Route to like a reply to a comment
commentRouter.patch("/replies/like/:id", authenticateToken, commentRepository.likeReply);

// Route to unlike a reply to a comment
commentRouter.patch("/replies/unlike/:id", authenticateToken, commentRepository.unlikeReply);

module.exports = { commentRouter };
