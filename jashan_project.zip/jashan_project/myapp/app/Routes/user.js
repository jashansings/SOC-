const express = require("express");
const userRouter = express.Router();
const { authenticateToken } = require("../Routes/authentication/auth-router");
const { userRepository } = require("../Repository/user-repository");

// Route to edit user profile
userRouter.patch("/editProfile", authenticateToken, userRepository.editProfile);

// Route to follow a user
userRouter.patch("/follow/:id", authenticateToken, userRepository.followUser);

// Route to unfollow a user
userRouter.patch("/unfollow/:id", authenticateToken, userRepository.unfollowUser);

// Route to view a user's profile
userRouter.get("/viewProfile/:id", authenticateToken, userRepository.viewUserProfile);

module.exports = { userRouter };
