const mongoose = require("mongoose");

module.exports = {
    initializeDatabase: async () => {
        try {
            mongoose.connect('mongodb://localhost:27017/chirpItApp',
                {
                    dbName: "chirpItApp",
                }
            );
            console.log("Connected to MongoDB");
        } catch (error) {
            console.error("Error connecting to MongoDB:", error.message);
        }
    }
};
