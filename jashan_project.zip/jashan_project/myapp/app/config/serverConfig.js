const dotenv = require("dotenv");

dotenv.config();

module.exports = {
  SERVER_PORT: process.env.PORT || 3000,
};
