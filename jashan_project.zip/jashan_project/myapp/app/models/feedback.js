const mongoose = require("mongoose");

const commentSchema = new mongoose.Schema(
    {   
        author: { type: mongoose.Schema.Types.ObjectId, ref: 'ChirpUser', required: true },
        comment: { type: String, required: true, maxlength: 50 },
        likeCount: { type: Number, default: 0 },
        likedBy: [{
            type: mongoose.Schema.Types.ObjectId, ref: 'ChirpUser',
        }],
        responses: [{
            type: mongoose.Schema.Types.ObjectId,
            ref: 'Response'
        }],
        associatedPost: { type: mongoose.Schema.Types.ObjectId, ref: 'ChirpPost', required: true }
    
    }, { timestamps: true }
);

const Comment = mongoose.model('Comment', commentSchema);

const responseSchema = new mongoose.Schema(
    {
        author: { type: mongoose.Schema.Types.ObjectId, ref: 'ChirpUser', required: true },
        response: { type: String, required: true },
        likeCount: { type: Number, default: 0 },
        likedBy: [{
            type: mongoose.Schema.Types.ObjectId, ref: 'ChirpUser',
        }],
        associatedComment: { type: mongoose.Schema.Types.ObjectId, ref: 'Comment', required: true }
    }
);

const Response = mongoose.model('Response', responseSchema);

module.exports = { Comment, Response };

// Example content for feedback model
class Feedback {
    constructor(content) {
      this.content = content;
    }
    // Define methods or properties here
  }
  
  module.exports = Feedback;
  