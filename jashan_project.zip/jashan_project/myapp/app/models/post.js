const mongoose = require("mongoose");

// Schema for user posts
const postSchema = new mongoose.Schema(
    {
        content: { type: String, required: true, maxlength: 250 },
        image: { type: Buffer },
        imageType: { type: String },
        author: { type: mongoose.Schema.Types.ObjectId, ref: 'ChirpUser', required: true },
        likes: [{ type: mongoose.Schema.Types.ObjectId, ref: 'ChirpUser' }],
        totalLikes: { type: Number, default: 0 },
        comments: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Comment' }]
    }, { timestamps: true }
);

const Post = mongoose.model('ChirpPost', postSchema);

module.exports = { Post };
