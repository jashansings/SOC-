const mongoose = require("mongoose");

// Schema for tokens
const tokenSchema = new mongoose.Schema(
    {
        token: { type: String, required: true },
        userId: { type: mongoose.Schema.Types.ObjectId, ref: 'ChirpUser', required: true }
    }
);

const AuthToken = mongoose.model("AuthToken", tokenSchema);

module.exports = { AuthToken };
