const mongoose = require("mongoose");
const Schema = mongoose.Schema;
const bcrypt = require("bcrypt");

// Schema for user profiles
const userSchema = new mongoose.Schema({
  username: { type: String, unique: true },
  name: { type: String, required: true },
  bio: { type: String },
  gender: { type: String, enum: ["Male", "Female", "Prefer not to say"] },
  followerCount: { type: Number, default: 0 },
  followers: [{ type: Schema.Types.ObjectId, ref: "ChirpUser", default: [] }],
  following: [{ type: Schema.Types.ObjectId, ref: "ChirpUser", default: [] }],
  password: { type: String, required: true },
  posts: [{ type: Schema.Types.ObjectId, ref: "ChirpPost" }]
});

// Hash the password before saving
userSchema.pre("save", async function (next) {
  if (!this.isModified("password")) {
    return next();
  }
  try {
    const salt = await bcrypt.genSalt(10);
    this.password = await bcrypt.hash(this.password, salt);
    next();
  } catch (err) {
    next(err);
  }
});

// Compare candidate password with hashed password
userSchema.methods.comparePassword = function (candidatePassword) {
  return bcrypt.compare(candidatePassword, this.password);
};

const UserProfile = mongoose.model("ChirpUser", userSchema);

module.exports = { UserProfile };
